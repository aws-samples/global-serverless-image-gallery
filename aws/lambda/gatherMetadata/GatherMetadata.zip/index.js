const util = require('util');
const AWS = require('aws-sdk');
const rekognition = new AWS.Rekognition();
const ddb = new AWS.DynamoDB({ apiVersion: '2012-10-08' });


exports.handler = function(event, context) {
    console.log("Reading input from event:\n", util.inspect(event, { depth: 5 }));

    const srcBucket = event.Records[0].s3.bucket.name;
    // Object key may have spaces or unicode non-ASCII characters.
    const srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));

    var params = {
        Image: {
            S3Object: {
                Bucket: srcBucket,
                Name: srcKey
            }
        },
        MaxLabels: 10,
        MinConfidence: 60
    };

    rekognition.detectLabels(params).promise().then(function(data) {
        console.log(" Data for src " + srcKey);
        console.log(" Labels : " + util.inspect(data, { depth: 3 }));
        addMetadata(event, srcKey, data);
    }).catch(function(err) {
        console.log("Error updating the metadata for" + srcKey);
    });

};

var addMetadata = function(event, srcKey, data) {
    var params = {
        TableName: 'ImageMetadata',
        Item: {
            'IMG_ID': { S: srcKey },
            'CUSTOMER_NAME': { S: 'Richard Roe' },
        }
    };
    data.Labels.forEach(function(label) {
        var confidence = parseFloat(label.Confidence);
        console.log(" In addMetadata function " + confidence);
        var params = {
            TableName: process.env.TBL_NAME,
            Item: {
                'img_id': { S: srcKey },
                'name': { S: label.Name },
                'confidence': { N: label.Confidence + "" }
            }
        };
        console.log(" In addMetadata function " + util.inspect(params, { depth: 3 }));
        // Call DynamoDB to add the item to the table
        ddb.putItem(params, function(err, data) {
            if (err) {
                console.log("Error", err);
            } else {
                console.log("Success", data);
            }
        });
    })

}
