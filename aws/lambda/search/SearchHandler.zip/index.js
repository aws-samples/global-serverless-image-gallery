const util = require('util');
const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB({ apiVersion: '2012-10-08' });
const s3 = new AWS.S3({apiVersion: '2006-03-01'});

exports.handler = (event, context, callback) => {
    console.log("Reading input from event:\n", util.inspect(event, { depth: 5 }));
   
    // Object key may have spaces or unicode non-ASCII characters.
    const srcKey = event.searchKey;

    var filelist = [];

    var items = searchDDB(srcKey, function(items) {
        
        items.forEach(function(item, index, array) {
            var imgJson = {};
            imgJson["name"] = item.img_id.S;
            imgJson["sUrl"] = getSignedS3URL(item.img_id.S);
            imgJson["confidence"] = item.confidence.N;
            filelist.push(imgJson);
    
        });
        console.log("Reading output:\n", util.inspect(filelist, { depth: 5 }));
         context.done(null, filelist);
    });
};

var searchDDB = function(searchKey, callback) {

    var params = {
        TableName: process.env.TBL_NAME,
        KeyConditionExpression: "#nm = :nVal",
        ExpressionAttributeNames:{
            "#nm": "name"
        },
        ExpressionAttributeValues:{
            ":nVal": {'S':searchKey}
        }
    };
    ddb.query(params, function(err, data) {
        if (err) {
            console.log("Error", err);
            return false;
        } else {
            data.Items.forEach(function(element, index, array) {
                console.log(element.name.S + " (" + element.img_id.S + ")");
            });
            callback(data.Items);
        }
    });
}

var getSignedS3URL = function(imgId) {
    var params = { Bucket:  process.env.BUCKET, Key: imgId };
    return s3.getSignedUrl('getObject', params);
}